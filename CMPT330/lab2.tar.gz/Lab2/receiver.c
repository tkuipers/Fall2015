//
//  YOUR NAME HERE!
//  YOUR ID HERE!
// 
//  receiver.c
//

#include "common.h"

int main() {
  
  return 0;
}