//
//  charlie.c
//  ChocolateFactory
//  CMPT 330 -- Fall 2013
//
//  YOUR NAME
//  DATE
//

#include "ChocolateFactory.h"

int main () {

  exit(EXIT_SUCCESS);
  
}