//
//  Tyler Kuipers
//  120065
// 
//  common.c
//  



#include <stdio.h>
#include <sys/prctl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <stdlib.h>

char* trimwhitespace(char* firstline);